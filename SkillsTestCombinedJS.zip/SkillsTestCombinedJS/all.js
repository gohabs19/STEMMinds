//typing test

let promptText = '';
let textOrder = [];
let numPressed = 0;
let keyPressed;
let currentWord = 1;
prompt = document.getElementById("prompt");

let wordsCorrect = 0;
let wordsIncorrect = 0;
let interval;

let isTiming = false;

let timer = 0;
let accuracy;
let wpm;

let testLen = 0;

let numOfCodes;

let questions = ['Which cube can NOT be created from the following net?: ', 'Which square is the same as the first one'];
let questionImages = ['images/overallNet.png', 'images/stemSquare1.png'];
let answers0 = ['stemCube1', 'stemCube2', 'stemCube3','stemCube4'];
let answers1 = ['stemSquare2', 'stemSquare3', 'stemSquare4', 'stemSquare5'];
//let answers2 = ['yes', 'no, I would rather focus on the code itself', 'i\'m not interested in the code at all, only the financial part!'];
let answers = [answers0, answers1];//, answers2];
let questionElement;
let answerElement = [];

let askedQuestions = [];
let askedAnswers = [];
let j = 0;

var playerPiece;
let numOfMoves = 0;
let codeText;
let codeElements = [];
let z = 0;


let mcquestions = ['Which would be your first choice of activity?: ', 'Would you rather build a bridge, or make an app?', 'are you interested in business, and how to sell the things you\'ve built?', 'How do you/your child typically respond when faced with a challenge?'];
let mcanswers0 = ['photography', 'movie creation', 'coding'];
let mcanswers1 = ['bridge', 'app', 'neither'];
let mcanswers2 = ['yes', 'no, I would rather focus on the code itself', 'i\'m not interested in the code at all, only the financial part!'];
let mcanswers3 = ['Work through it independently', 'work through it with support', 'Struggle to ask for help'];
let mcanswers = [answers0, answers1, answers2, answers3];
let mcquestionElement;
let mcanswerElement = [];

let mcaskedQuestions = [];
let mcaskedAnswers = [];
let h = 0;

var myGameArea = {
    canvas : document.createElement("canvas"),
    start : function() {
        this.canvas.width = 480;
        this.canvas.height = 270;
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.interval = setInterval(updateGameArea, 20);
    },
    clear : function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

function mcGenQuestion(){
    let i = 0;
    let k = 0;
    let answer;

    randomQuestionIndex = Math.floor(Math.random() * mcquestions.length);
    let currentQuestion = mcquestions[randomQuestionIndex];

    while (mcaskedQuestions.includes(currentQuestion)){
        randomQuestionIndex = Math.floor(Math.random() * mcquestions.length);
        currentQuestion = mcquestions[randomQuestionIndex];
    }

    document.getElementById('question').innerHTML = currentQuestion; //Randomly selected question.

    while ( i < answers[randomQuestionIndex].length ){
        document.getElementById('mcanswers' + i).innerHTML = mcanswers[randomQuestionIndex][i];
        document.getElementById('mcanswers' + i).onclick = function(){
            mcaskedAnswers[j] = this.innerHTML;
            mcaskedQuestions[j] = currentQuestion;

            //alert(this.innerHTML);
            if (j < 3){
                genQuestion();
            }
            j++;
        }
        
        i++;
    }

    /*i = 0;
    while (i < answers[randomQuestionIndex].length){
        answerElement[i].onclick = function(){
            askedAnswers[j] = this.innerHTML;
            askedQuestions[j] = currentQuestion;

            alert(this.innerHTML);

            genQuestion();
            j++;
        }
    }*/
}

function startGame() {
    playerPiece = new component(30, 30, "rgb(0, 191, 255)", 30, 120);
    winGamePiece = new component(30, 30, 'yellow', 420, 120);
    wall1 = new component(240, 30, '#ff5050', 0, 240);
    wall2 = new component(150, 30, '#ff5050', 30, 180);
    wall3 = new component(150, 30, '#ff5050', 30, 90);
    wall4 = new component(30, 180, '#ff5050', 210, 60);
    wall5 = new component(30, 180, '#ff5050', 270, 60);
    wall6 = new component(150, 30, '#ff5050', 270, 180);
    wall7 = new component(30, 150, '#ff5050', 330, 0);
    myGameArea.start();
}



function component(width, height, color, x, y) {
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;
    this.x = x;
    this.y = y;    
    this.update = function() {
        ctx = myGameArea.context;
        ctx.fillStyle = color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
    this.newPos = function() {
        this.x += this.speedX;
        this.speedX = 0;
        this.y += this.speedY;
        this.speedY = 0;
    }    
}

function updateGameArea() {
    myGameArea.clear();
    playerPiece.newPos();    
    playerPiece.update();
    winGamePiece.update();
    wall1.update();
    wall2.update();
    wall3.update();
    wall4.update();
    wall5.update();
    wall6.update();
    wall7.update();

    if (playerPiece.x == winGamePiece.x && playerPiece.y == winGamePiece.y){

    }
    if (playerPiece.y == wall1.y || playerPiece.y == wall2.y){
        console.log('lose');
    }
}

function empty(){
    document.getElementById('codeStage').textContent = '';
}


function moveup() {
    document.getElementById('codeStage').textContent += ('Up ');
    
}

function movedown() {
    //let moveDown = document.createElement('h3');
    //moveDown.id = 'down';
    //moveDown.innerHTML = '<br>Down ';
    document.getElementById('codeStage').textContent += ('Down ');
}

function moveleft() {
    document.getElementById('codeStage').textContent += ('Left ');
    
}

function moveright() {
    document.getElementById('codeStage').textContent += ('Right ');
    
}

function loop(){
    let x = document.getElementById('loopNum').value;
    document.getElementById('codeStage').textContent += ('Loop '+x+' ');
}

function endLoop(){
    document.getElementById('codeStage').textContent += ('EndLoop ');
}

function run(){
    let fullCode = document.getElementById('codeStage').innerText;
    let code = fullCode.split(" ");

    //alert(fullCode);

    let i = 0;
    while (i < code.length){

        if (code[i] == 'Up'){
            playerPiece.speedY -= 30; 
            numOfMoves++;
        } else if (code[i] == 'Down'){
            playerPiece.speedY += 30; 
            numOfMoves++;
        } else if (code[i] == 'Left'){
            playerPiece.speedX -= 30; 
            numOfMoves++;
        } else if (code[i] == 'Right'){
            playerPiece.speedX += 30; 
            numOfMoves++;
        } else if (code[i] == 'Loop'){
            let k = 0;
            let numOfLoops = code[i+1];

            while (k < numOfLoops){
                let j = i+2;
                while (code[j] != 'EndLoop'){

                    if (code[j] == 'Up'){
                        playerPiece.speedY -= 30; 
                        numOfMoves++;
                    } else if (code[j] == 'Down'){
                        playerPiece.speedY += 30; 
                        numOfMoves++;
                    } else if (code[j] == 'Left'){
                        playerPiece.speedX -= 30; 
                        numOfMoves++;
                    } else if (code[j] == 'Right'){
                        playerPiece.speedX += 30; 
                        numOfMoves++;
                    }

                    j=j+1;
                }
                k=k+1;
            }
            i = j;
        }

        i++;
    }
}

function genQuestion(){
    let i = 0;
    let k = 0;
    let answer;

    randomQuestionIndex = Math.floor(Math.random() * questions.length);
    let currentQuestion = questions[randomQuestionIndex];

    while (askedQuestions.includes(currentQuestion)){
        randomQuestionIndex = Math.floor(Math.random() * questions.length);
        currentQuestion = questions[randomQuestionIndex];
    }

    document.getElementById('question').innerHTML = currentQuestion; //Randomly selected question.
    document.getElementById('questionImages').src = questionImages[randomQuestionIndex];
    while ( i < answers[randomQuestionIndex].length ){
        //alert(answers[randomQuestionIndex][i]);
        document.getElementById('answers' + i).src = 'images/'+answers[randomQuestionIndex][i]+'.png';
        document.getElementById('answers' + i).onclick = function(){
            askedAnswers[j] = this.innerHTML;
            askedQuestions[j] = currentQuestion;

            //alert(this.innerHTML);
            if (j < 1){
                genQuestion();
            }
            j++;
        }
        
        i++;
    }

    /*i = 0;
    while (i < answers[randomQuestionIndex].length){
        answerElement[i].onclick = function(){
            askedAnswers[j] = this.innerHTML;
            askedQuestions[j] = currentQuestion;

            alert(this.innerHTML);

            genQuestion();
            j++;
        }
    }*/
}

function generatePrompt(){
    let currentLine = 0;
    let random;
    //let words = ['this', 'hello', 'for', 'while', 'let', 'console', 'if', 'else', ';', 'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'I', 'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at', 'this', 'but', 'his', 'by', 'from', 'they', 'her', 'she'];
    let code0 = ["function", "startTime(){",
        "br", "tab", "if", "(isTiming", "==", "false){",
        "br", "tab", "tab", "interval", "=", "setInterval","(function(){", "timer", "+=", "0.1}", "100);",
        "br", "tab", "isTiming", "=", "true;",
        "br", "}}"];

    let code1 = ["if", "(keyPressed", "==", 'true){',
            "br", "tab", "checkWord();",
            "br", "tab", "document.value", '=', 'null;',
        'br', '}'];

    let code2 = ['sharks', '=', '[\'hammerhead\',', '\'great', 'white\']',
                'br','for', 'item', 'in', 'range(len(sharks)):',
                    'br', 'tab', 'sharks.append(\'shark\')',
                'br', 'print(sharks)']

    let codeSnippets = [code0, code1, code2];
    numOfCodes = codeSnippets.length;
    let numOfSpacing = [8, 5, 4];

    random = Math.floor(Math.random() * numOfCodes);

    let i = 0;
    let j = 0;

    arrayLen = codeSnippets[random].length;
    testLen = codeSnippets[random].length - numOfSpacing[random];

    let wordElements = [];
    let tab;

    while ( i < arrayLen ){
    
        /*random = Math.floor(Math.random() * code1.length)
        if (random != 8){
            promptText += ' ';
        }*/
        if (codeSnippets[random][i] == 'br'){
            currentLine++;
        } else if (codeSnippets[random][i] == 'tab'){
            tab = document.createElement('td');
            tab.innerHTML = '&nbsp'//'<pre class="tab">  </pre>';
            document.getElementById("textArea"+currentLine).appendChild(tab);
        }else{
            promptText += (codeSnippets[random][i]);
            textOrder[i] = codeSnippets[random][i];

            wordElements[i] = document.createElement('td');
            wordElements[i].id = 'word'+j;
            wordElements[i].innerHTML = codeSnippets[random][i];
            document.getElementById("textArea"+currentLine).appendChild(wordElements[i]);
            j++;
        }
        i = i + 1;


    }
    
    wordElements[testLen] = document.createElement('td');
    wordElements[testLen].id = 'word'+testLen;
    wordElements[testLen].innerHTML = '';
    document.getElementById("textArea"+currentLine).appendChild(wordElements[testLen]);

}

function startTime(){
    if (isTiming == false){
        interval = setInterval(function(){ timer += 0.1 }, 100);
        isTiming = true;
    }
    
}

function stopTime(){
    clearInterval(interval);
    document.getElementById("timer").innerText = ''+timer.toFixed(2);
}
    

function getKeyPressed(event) {
    startTime();
    var char = event.which || event.keyCode;
    keyPressed = String.fromCharCode(char)
    
    if (keyPressed == ' ' || char == 13){
        checkWord();
        document.getElementById("inputField").value = null;
    }

    /*if (keyPressed == promptText.charAt(numPressed+1)){
        document.getElementById("correct").innerHTML = "Correct, numPressed: " + numPressed;
    } else{
        document.getElementById("correct").innerHTML = "Incorrect, the correct key is: " + promptText.charAt(numPressed);
    }*/
    
    numPressed++;
}

function restart() {
    location.reload();
}

function checkWord() {

        document.getElementById("word"+currentWord).style.backgroundColor = '#d4d4d4';
        if (currentWord == testLen){
            stopTime();
            accuracy = ((wordsCorrect/(testLen-1))*100).toFixed(2);
            document.getElementById("accuracy").innerText = accuracy+'';
            wpm = ((60/timer)*wordsCorrect).toFixed(2);
            document.getElementById("wpm").innerText = wpm+'';
        }

        if (currentWord != 0){
            if (document.getElementById("inputField").value.trim() == document.getElementById("word"+(currentWord-1)).innerText){
                document.getElementById("word"+(currentWord-1)).style.backgroundColor = '#6bb84f';
                wordsCorrect++;
            } else{
                document.getElementById("word"+(currentWord-1)).style.backgroundColor = '#ff6970';
                wordsIncorrect++;
            }
            
        }
        currentWord++;
}

function upload(uploadedFile){

    // Load the SDK and UUID
    var AWS = require('aws-sdk');
    alert('hello');
    var uuid = require('uuid');

    // Create unique bucket name
    var bucketName = 'node-sdk-sample-' + uuid.v4();
    // Create name for uploaded object key
    var keyName = 'hello_world.txt';

    // Create a promise on S3 service object
    var bucketPromise = new AWS.S3({apiVersion: '2006-03-01'}).createBucket({Bucket: bucketName}).promise();

    // Handle promise fulfilled/rejected states
    bucketPromise.then(
    function(data) {
        // Create params for putObject call
        var objectParams = {Bucket: bucketName, Key: keyName, Body: 'Hello World!'};
        // Create object upload promise
        var uploadPromise = new AWS.S3({apiVersion: '2006-03-01'}).putObject(objectParams).promise();
        uploadPromise.then(
        function(data) {
            console.log("Successfully uploaded data to " + bucketName + "/" + keyName);
        });
    }).catch(
    function(err) {
        console.error(err, err.stack);
    });

}


function typingTestRun(){
    generatePrompt();
    document.getElementById("word0").style.backgroundColor = '#d4d4d4';
    document.getElementById("inputField").focus();
    document.getElementById("inputField").select();
    upload('typingData.txt');
}

function qualitativeTestRun(){
    genQuestion();
}

function multipleChoiceRun(){
    mcGenQuestion();
}